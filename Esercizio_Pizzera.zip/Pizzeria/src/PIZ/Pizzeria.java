package PIZ;

public class Pizzeria {
    public static void main(String[] args) {
        int numCamerieri = 3;
        int numTavoli = 20;
        int capienzaMassima = 100;

        // Creiamo il forno
        Forno forno = new Forno();

        // Creiamo i tavoli
        Tavolo[] tavoli = new Tavolo[numTavoli];
        for (int i = 0; i < numTavoli; i++) {
            tavoli[i] = new Tavolo(i + 1);
        }

        // Creiamo e avviamo i camerieri
        Thread[] camerieri = new Thread[numCamerieri];
        for (int i = 0; i < numCamerieri; i++) {
            camerieri[i] = new Thread(new Cameriere(forno, tavoli), "Cameriere " + (i + 1));
            camerieri[i].start();
        }

        // Avvia la produzione del forno
        Thread fornoThread = new Thread(forno, "Forno");
        fornoThread.start();

        // Attendiamo che i camerieri finiscano
        for (Thread cameriere : camerieri) {
            try {
                cameriere.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Terminare il programma
        System.out.println("Tutte le pizze sono state consegnate.");
    }
}
