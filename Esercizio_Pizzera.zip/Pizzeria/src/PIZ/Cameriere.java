package PIZ;

import java.util.Random;

public class Cameriere implements Runnable {
    private Forno forno;
    private Tavolo[] tavoli;
    private Random random = new Random();

    public Cameriere(Forno forno, Tavolo[] tavoli) {
        this.forno = forno;
        this.tavoli = tavoli;
    }

    @Override
    public void run() {
        while (true) {
            try {
                // Simuliamo la presa dell'ordine
                Tavolo tavolo = prendiOrdine();
                System.out.println(Thread.currentThread().getName() + " ha preso l'ordine dal Tavolo " + tavolo.getId());

                // Attende che ci sia una pizza disponibile
                Integer pizza = forno.prendiPizza();
                if (pizza == null) {
                    break; // Se non ci sono più pizze e il forno è chiuso, esce
                }

                System.out.println(Thread.currentThread().getName() + " ha preso una pizza dal forno");

                // Serve la pizza al tavolo
                servePizze(tavolo);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    private Tavolo prendiOrdine() {
        int tavoloIndex = random.nextInt(tavoli.length);
        return tavoli[tavoloIndex];
    }

    private void servePizze(Tavolo tavolo) {
        System.out.println(Thread.currentThread().getName() + " ha servito la pizza al Tavolo " + tavolo.getId());
        tavolo.serviPizza();
    }
}

