package PIZ;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class Forno implements Runnable {
    private List<Integer> pizzePronte = new LinkedList<>();
    private final int MAX_PIZZE = 8;
    private Random random = new Random();
    private boolean fornoAperto = true;

    public synchronized void chiudiForno() {
        fornoAperto = false;
        notifyAll();
    }

    public synchronized Integer prendiPizza() throws InterruptedException {
        while (pizzePronte.isEmpty() && fornoAperto) {
            wait(); // Attende che ci siano pizze pronte
        }
        if (!pizzePronte.isEmpty()) {
            Integer pizza = pizzePronte.remove(0);
            return pizza;
        } else {
            return null; // Il forno è chiuso e non ci sono più pizze
        }
    }

    @Override
    public synchronized void run() {
        try {
            while (fornoAperto) {
                int pizzeProdotte = random.nextInt(MAX_PIZZE) + 1;
                System.out.println(Thread.currentThread().getName() + " ha prodotto " + pizzeProdotte + " pizze.");
                for (int i = 0; i < pizzeProdotte; i++) {
                    pizzePronte.add(1); // Aggiunge una pizza alla lista
                }
                notifyAll(); // Notifica i camerieri che ci sono pizze pronte
                Thread.sleep(3000); // Simula il tempo di produzione
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            chiudiForno();
        }
    }
}
