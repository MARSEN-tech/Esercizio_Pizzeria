package PIZ;

public class Tavolo {
    private int id;
    private int personeSedute;

    public Tavolo(int id) {
        this.id = id;
        this.personeSedute = (int) (Math.random() * 5) + 1; // Simuliamo 1-5 persone per tavolo
    }

    public int getId() {
        return id;
    }

    public int getPersoneSedute() {
        return personeSedute;
    }

    public void serviPizza() {
        System.out.println("Il Tavolo " + id + " ha ricevuto la pizza.");
    }
}
